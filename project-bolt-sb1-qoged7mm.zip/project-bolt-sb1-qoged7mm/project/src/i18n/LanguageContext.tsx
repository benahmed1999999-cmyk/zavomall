import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import {
  dictionaries,
  localeDir,
  localeNames,
  type Locale,
} from "./translations";

type LanguageContextValue = {
  locale: Locale;
  dir: "rtl" | "ltr";
  t: (key: string) => string;
  setLocale: (locale: Locale) => void;
  localeNames: Record<Locale, string>;
};

const LanguageContext = createContext<LanguageContextValue | null>(null);

const STORAGE_KEY = "zavomall.locale";

function getInitialLocale(): Locale {
  if (typeof window === "undefined") return "ar";
  const stored = window.localStorage.getItem(STORAGE_KEY);
  if (stored === "ar" || stored === "en" || stored === "fr") return stored;
  return "ar";
}

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>(getInitialLocale);

  const dir = localeDir[locale];

  useEffect(() => {
    const html = document.documentElement;
    html.lang = locale;
    html.dir = dir;
    window.localStorage.setItem(STORAGE_KEY, locale);
  }, [locale, dir]);

  const value = useMemo<LanguageContextValue>(
    () => ({
      locale,
      dir,
      localeNames,
      setLocale: setLocaleState,
      t: (key: string) => dictionaries[locale][key] ?? dictionaries.en[key] ?? key,
    }),
    [locale, dir],
  );

  return (
    <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>
  );
}

export function useLanguage() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error("useLanguage must be used within LanguageProvider");
  return ctx;
}
