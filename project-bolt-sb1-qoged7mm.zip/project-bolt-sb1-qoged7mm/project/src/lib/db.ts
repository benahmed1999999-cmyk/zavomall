import { supabase } from "./supabase";
import type { ShopRow, ProductRow } from "./db-types";
import type { Shop, Product } from "@/data/types";

function mapShop(row: ShopRow): Shop {
  return {
    id: row.id,
    slug: row.slug,
    name: row.name,
    tagline: row.tagline,
    about: row.about,
    country: row.country,
    city: row.city,
    category: row.category,
    tags: (row.tags ?? []) as Shop["tags"],
    logo: row.logo,
    cover: row.cover,
    joinedYear: new Date(row.created_at).getFullYear(),
    contactEmail: row.contact_email,
    contactPhone: row.contact_phone,
  };
}

function mapProduct(row: ProductRow): Product {
  return {
    id: row.id,
    shopId: row.shop_id,
    title: row.title,
    description: row.description,
    price: Number(row.price),
    currency: row.currency as Product["currency"],
    category: row.category,
    country: row.country,
    city: row.city,
    image: row.image,
    createdAt: row.created_at,
    status: row.status,
  };
}

export async function fetchShops(): Promise<Shop[]> {
  if (!supabase) return [];
  const { data, error } = await supabase.from("shops").select("*").order("created_at", { ascending: false });
  if (error) throw error;
  return (data as ShopRow[]).map(mapShop);
}

export async function fetchShop(slugOrId: string): Promise<Shop | null> {
  if (!supabase) return null;
  const col = slugOrId.length === 36 && slugOrId.includes("-") ? "id" : "slug";
  const { data, error } = await supabase.from("shops").select("*").eq(col, slugOrId).maybeSingle();
  if (error) throw error;
  return data ? mapShop(data as ShopRow) : null;
}

export async function fetchShopProducts(shopId: string): Promise<Product[]> {
  if (!supabase) return [];
  const { data, error } = await supabase
    .from("products")
    .select("*")
    .eq("shop_id", shopId)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return (data as ProductRow[]).map(mapProduct);
}

export async function fetchProduct(id: string): Promise<Product | null> {
  if (!supabase) return null;
  const { data, error } = await supabase.from("products").select("*").eq("id", id).maybeSingle();
  if (error) throw error;
  return data ? mapProduct(data as ProductRow) : null;
}

export async function fetchAllProducts(): Promise<Product[]> {
  if (!supabase) return [];
  const { data, error } = await supabase
    .from("products")
    .select("*")
    .order("created_at", { ascending: false });
  if (error) throw error;
  return (data as ProductRow[]).map(mapProduct);
}

export async function fetchRelatedProducts(category: string, excludeId: string, limit = 4): Promise<Product[]> {
  if (!supabase) return [];
  const { data, error } = await supabase
    .from("products")
    .select("*")
    .eq("category", category)
    .eq("status", "active")
    .neq("id", excludeId)
    .order("created_at", { ascending: false })
    .limit(limit);
  if (error) throw error;
  return (data as ProductRow[]).map(mapProduct);
}

export async function fetchRelatedShops(category: string, excludeId: string, limit = 3): Promise<Shop[]> {
  if (!supabase) return [];
  const { data, error } = await supabase
    .from("shops")
    .select("*")
    .eq("category", category)
    .neq("id", excludeId)
    .limit(limit);
  if (error) throw error;
  return (data as ShopRow[]).map(mapShop);
}

export async function fetchMyShop(): Promise<Shop | null> {
  if (!supabase) return null;
  const { data, error } = await supabase
    .from("shops")
    .select("*")
    .not("owner_id", "is", null)
    .order("created_at", { ascending: false })
    .limit(1);
  if (error) throw error;
  if (!data || data.length === 0) return null;
  return mapShop(data[0] as ShopRow);
}
