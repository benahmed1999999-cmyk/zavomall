import type { Locale } from "@/i18n/translations";
import type { CategoryId, Currency } from "@/data/types";

export type LocalizedJSON = Record<Locale, string>;

export type ShopRow = {
  id: string;
  owner_id: string | null;
  slug: string;
  name: LocalizedJSON;
  tagline: LocalizedJSON;
  about: LocalizedJSON;
  country: string;
  city: LocalizedJSON;
  category: CategoryId;
  tags: LocalizedJSON[];
  logo: string;
  cover: string;
  contact_email: string;
  contact_phone: string;
  created_at: string;
};

export type ProductRow = {
  id: string;
  shop_id: string;
  title: LocalizedJSON;
  description: LocalizedJSON;
  price: number;
  currency: Currency;
  category: CategoryId;
  country: string;
  city: LocalizedJSON;
  image: string;
  status: "active" | "draft";
  created_at: string;
};

export type ShopWithProducts = ShopRow & { products: ProductRow[] };

export type ShopInput = {
  slug: string;
  name: LocalizedJSON;
  tagline: LocalizedJSON;
  about: LocalizedJSON;
  country: string;
  city: LocalizedJSON;
  category: CategoryId;
  tags: LocalizedJSON[];
  logo: string;
  cover: string;
  contact_email: string;
  contact_phone: string;
};

export type ProductInput = {
  shop_id: string;
  title: LocalizedJSON;
  description: LocalizedJSON;
  price: number;
  currency: Currency;
  category: CategoryId;
  country: string;
  city: LocalizedJSON;
  image: string;
  status: "active" | "draft";
};

export type ShopUpdate = Partial<Omit<ShopInput, "slug">>;
export type ProductUpdate = Partial<Omit<ProductInput, "shop_id">>;
