/*
# Create shops, products tables and storage buckets

## What this migration does
Creates the core database schema for the Zavomall marketplace so that seller shops
and their products persist in the real Supabase database and can be browsed by
visitors without logging in, while only the shop owner can modify their own data.

## New tables
1. `shops`
   - `id` uuid primary key
   - `owner_id` uuid — the seller who owns this shop (defaults to the authenticated
     user via `auth.uid()`). NULL for seeded demo shops that no one can edit.
   - `slug` text, unique — URL-safe identifier for the public shop page
   - `name` jsonb — localized shop name ({ar,en,fr})
   - `tagline` jsonb — localized short description
   - `about` jsonb — localized longer description
   - `country` text — ISO country code (e.g. "FR")
   - `city` jsonb — localized city name
   - `category` text — one of the fixed category ids
   - `tags` jsonb — array of localized tag strings
   - `logo` text — image URL
   - `cover` text — cover image URL
   - `contact_email` text
   - `contact_phone` text
   - `created_at` timestamptz

2. `products`
   - `id` uuid primary key
   - `shop_id` uuid — foreign key to shops(id) ON DELETE CASCADE
   - `title` jsonb — localized title
   - `description` jsonb — localized description
   - `price` numeric(12,2)
   - `currency` text — currency code
   - `category` text
   - `country` text
   - `city` jsonb — localized city name
   - `image` text — image URL
   - `status` text — 'active' | 'draft', defaults to 'active'
   - `created_at` timestamptz

## Storage buckets
- `shop-logos` (public) — seller logo & cover uploads
- `product-images` (public) — seller product image uploads

## Security (Row Level Security)
- `shops`: everyone (anon + authenticated) can SELECT (marketplace is public).
  Only the owner (auth.uid() = owner_id) can INSERT, UPDATE, DELETE.
  Seeded demo shops have owner_id = NULL so no one can modify them.
- `products`: everyone can SELECT. INSERT/UPDATE/DELETE only allowed when the
  product's shop belongs to the authenticated user (checked via EXISTS subquery
  against shops.owner_id).
- Storage: public read on both buckets; authenticated users can upload/update/delete
  only objects whose path starts with their own user id folder (e.g. `user-uuid/...`).

## Important notes
1. The `owner_id` column has `DEFAULT auth.uid()` so that a seller inserting a
   new shop via the frontend (which never sends owner_id) automatically gets
   ownership set from their authenticated session.
2. Demo/seed shops are inserted with owner_id = NULL. They are publicly readable
   but cannot be modified by anyone through the API.
3. No destructive operations are used — the migration is safe to re-run.
4. Seed shop IDs are fixed UUID literals so products can reference them via FK.
*/

-- =========================================================
-- shops table
-- =========================================================
CREATE TABLE IF NOT EXISTS shops (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  slug text UNIQUE NOT NULL,
  name jsonb NOT NULL DEFAULT '{}'::jsonb,
  tagline jsonb NOT NULL DEFAULT '{}'::jsonb,
  about jsonb NOT NULL DEFAULT '{}'::jsonb,
  country text NOT NULL DEFAULT '',
  city jsonb NOT NULL DEFAULT '{}'::jsonb,
  category text NOT NULL DEFAULT 'fashion',
  tags jsonb NOT NULL DEFAULT '[]'::jsonb,
  logo text NOT NULL DEFAULT '',
  cover text NOT NULL DEFAULT '',
  contact_email text NOT NULL DEFAULT '',
  contact_phone text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE shops ENABLE ROW LEVEL SECURITY;

-- Public read: marketplace is browsable without login
DROP POLICY IF EXISTS "shops_public_select" ON shops;
CREATE POLICY "shops_public_select"
  ON shops FOR SELECT
  TO anon, authenticated
  USING (true);

-- Owner can insert (owner_id defaults to auth.uid())
DROP POLICY IF EXISTS "shops_owner_insert" ON shops;
CREATE POLICY "shops_owner_insert"
  ON shops FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = owner_id);

-- Owner can update their own shop
DROP POLICY IF EXISTS "shops_owner_update" ON shops;
CREATE POLICY "shops_owner_update"
  ON shops FOR UPDATE
  TO authenticated
  USING (auth.uid() = owner_id)
  WITH CHECK (auth.uid() = owner_id);

-- Owner can delete their own shop
DROP POLICY IF EXISTS "shops_owner_delete" ON shops;
CREATE POLICY "shops_owner_delete"
  ON shops FOR DELETE
  TO authenticated
  USING (auth.uid() = owner_id);

-- =========================================================
-- products table
-- =========================================================
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  shop_id uuid NOT NULL REFERENCES shops(id) ON DELETE CASCADE,
  title jsonb NOT NULL DEFAULT '{}'::jsonb,
  description jsonb NOT NULL DEFAULT '{}'::jsonb,
  price numeric(12,2) NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'USD',
  category text NOT NULL DEFAULT 'fashion',
  country text NOT NULL DEFAULT '',
  city jsonb NOT NULL DEFAULT '{}'::jsonb,
  image text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'active',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE products ENABLE ROW LEVEL SECURITY;

-- Public read
DROP POLICY IF EXISTS "products_public_select" ON products;
CREATE POLICY "products_public_select"
  ON products FOR SELECT
  TO anon, authenticated
  USING (true);

-- Insert only if the shop belongs to the authenticated user
DROP POLICY IF EXISTS "products_owner_insert" ON products;
CREATE POLICY "products_owner_insert"
  ON products FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM shops
      WHERE shops.id = products.shop_id
        AND shops.owner_id = auth.uid()
    )
  );

-- Update only if the shop belongs to the authenticated user
DROP POLICY IF EXISTS "products_owner_update" ON products;
CREATE POLICY "products_owner_update"
  ON products FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM shops
      WHERE shops.id = products.shop_id
        AND shops.owner_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM shops
      WHERE shops.id = products.shop_id
        AND shops.owner_id = auth.uid()
    )
  );

-- Delete only if the shop belongs to the authenticated user
DROP POLICY IF EXISTS "products_owner_delete" ON products;
CREATE POLICY "products_owner_delete"
  ON products FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM shops
      WHERE shops.id = products.shop_id
        AND shops.owner_id = auth.uid()
    )
  );

-- Index for common queries
CREATE INDEX IF NOT EXISTS idx_products_shop_id ON products(shop_id);
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);
CREATE INDEX IF NOT EXISTS idx_products_country ON products(country);
CREATE INDEX IF NOT EXISTS idx_shops_owner_id ON shops(owner_id);
CREATE INDEX IF NOT EXISTS idx_shops_category ON shops(category);

-- =========================================================
-- Storage buckets
-- =========================================================
INSERT INTO storage.buckets (id, name, public)
VALUES ('shop-logos', 'shop-logos', true)
ON CONFLICT (id) DO NOTHING;

INSERT INTO storage.buckets (id, name, public)
VALUES ('product-images', 'product-images', true)
ON CONFLICT (id) DO NOTHING;

-- Public read for both buckets
DROP POLICY IF EXISTS "shop_logos_public_read" ON storage.objects;
CREATE POLICY "shop_logos_public_read"
  ON storage.objects FOR SELECT
  TO anon, authenticated
  USING (bucket_id = 'shop-logos');

DROP POLICY IF EXISTS "product_images_public_read" ON storage.objects;
CREATE POLICY "product_images_public_read"
  ON storage.objects FOR SELECT
  TO anon, authenticated
  USING (bucket_id = 'product-images');

-- Authenticated users can upload to shop-logos under their own user folder
DROP POLICY IF EXISTS "shop_logos_owner_upload" ON storage.objects;
CREATE POLICY "shop_logos_owner_upload"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'shop-logos'
    AND (storage.foldername(name))[1] = 'user-' || auth.uid()::text
  );

DROP POLICY IF EXISTS "shop_logos_owner_update" ON storage.objects;
CREATE POLICY "shop_logos_owner_update"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (
    bucket_id = 'shop-logos'
    AND (storage.foldername(name))[1] = 'user-' || auth.uid()::text
  )
  WITH CHECK (
    bucket_id = 'shop-logos'
    AND (storage.foldername(name))[1] = 'user-' || auth.uid()::text
  );

DROP POLICY IF EXISTS "shop_logos_owner_delete" ON storage.objects;
CREATE POLICY "shop_logos_owner_delete"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'shop-logos'
    AND (storage.foldername(name))[1] = 'user-' || auth.uid()::text
  );

-- Same for product-images
DROP POLICY IF EXISTS "product_images_owner_upload" ON storage.objects;
CREATE POLICY "product_images_owner_upload"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'product-images'
    AND (storage.foldername(name))[1] = 'user-' || auth.uid()::text
  );

DROP POLICY IF EXISTS "product_images_owner_update" ON storage.objects;
CREATE POLICY "product_images_owner_update"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (
    bucket_id = 'product-images'
    AND (storage.foldername(name))[1] = 'user-' || auth.uid()::text
  )
  WITH CHECK (
    bucket_id = 'product-images'
    AND (storage.foldername(name))[1] = 'user-' || auth.uid()::text
  );

DROP POLICY IF EXISTS "product_images_owner_delete" ON storage.objects;
CREATE POLICY "product_images_owner_delete"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'product-images'
    AND (storage.foldername(name))[1] = 'user-' || auth.uid()::text
  );

-- =========================================================
-- Seed sample shops (owner_id NULL = demo data, uneditable)
-- Fixed UUIDs so products can reference them.
-- =========================================================
INSERT INTO shops (id, owner_id, slug, name, tagline, about, country, city, category, tags, logo, cover, contact_email, contact_phone, created_at)
VALUES
  ('a0000001-0000-0000-0000-000000000001', NULL, 'lumiere-fashion',
    '{"ar":"لوميير للموضة","en":"Lumière Fashion","fr":"Lumière Fashion"}',
    '{"ar":"أزياء عصرية للرجال والنساء","en":"Modern fashion for men and women","fr":"Mode moderne pour hommes et femmes"}',
    '{"ar":"بيت أزياء فرنسي يقدّم قطعاً عصرية بجودة عالية منذ 2018.","en":"A French fashion house offering modern, high-quality pieces since 2018.","fr":"Maison de mode française proposant des pièces modernes et de qualité depuis 2018."}',
    'FR', '{"ar":"باريس","en":"Paris","fr":"Paris"}', 'fashion',
    '[{"ar":"ملابس","en":"Clothing","fr":"Vêtements"},{"ar":"إكسسوارات","en":"Accessories","fr":"Accessoires"}]',
    'https://images.pexels.com/photos/5531542/pexels-photo-5531542.jpeg?auto=compress&cs=tinysrgb&h=300&w=300',
    'https://images.pexels.com/photos/8311880/pexels-photo-8311880.jpeg?auto=compress&cs=tinysrgb&h=650&w=1600',
    'hello@lumiere-fashion.example', '+33 1 00 00 00 00', '2021-01-01')
ON CONFLICT (id) DO NOTHING;

INSERT INTO shops (id, owner_id, slug, name, tagline, about, country, city, category, tags, logo, cover, contact_email, contact_phone, created_at)
VALUES
  ('a0000002-0000-0000-0000-000000000002', NULL, 'souk-teck-electronics',
    '{"ar":"سوق تك للإلكترونيات","en":"Souk Tech Electronics","fr":"Souk Tech Électronique"}',
    '{"ar":"أجهزة تقنية وملحقات بأسعار تنافسية","en":"Tech devices and accessories at competitive prices","fr":"Appareils tech et accessoires à prix compétitifs"}',
    '{"ar":"متجر إلكترونيات في دبي متخصص في الأجهزة وملحقاتها.","en":"A Dubai electronics store specializing in devices and accessories.","fr":"Boutique d''électronique à Dubaï, spécialisée en appareils et accessoires."}',
    'AE', '{"ar":"دبي","en":"Dubai","fr":"Dubaï"}', 'electronics',
    '[{"ar":"حواسيب","en":"Computers","fr":"Ordinateurs"},{"ar":"ملحقات","en":"Accessories","fr":"Accessoires"}]',
    'https://images.pexels.com/photos/10357005/pexels-photo-10357005.jpeg?auto=compress&cs=tinysrgb&h=300&w=300',
    'https://images.pexels.com/photos/38555192/pexels-photo-38555192.jpeg?auto=compress&cs=tinysrgb&h=650&w=1600',
    'info@souktech.example', '+971 50 000 0000', '2022-01-01')
ON CONFLICT (id) DO NOTHING;

INSERT INTO shops (id, owner_id, slug, name, tagline, about, country, city, category, tags, logo, cover, contact_email, contact_phone, created_at)
VALUES
  ('a0000003-0000-0000-0000-000000000003', NULL, 'nile-mobile',
    '{"ar":"نايل موبايل","en":"Nile Mobile","fr":"Nile Mobile"}',
    '{"ar":"هواتف ذكية وملحقات أصلية","en":"Genuine smartphones and accessories","fr":"Smartphones et accessoires authentiques"}',
    '{"ar":"متجر هواتف في القاهرة يوفّر أحدث الموديلات وضمان رسمي.","en":"A Cairo phone store providing the latest models with official warranty.","fr":"Boutique de téléphones au Caire, derniers modèles avec garantie officielle."}',
    'EG', '{"ar":"القاهرة","en":"Cairo","fr":"Le Caire"}', 'phones',
    '[{"ar":"هواتف","en":"Phones","fr":"Téléphones"},{"ar":"ملحقات","en":"Accessories","fr":"Accessoires"}]',
    'https://images.pexels.com/photos/7068406/pexels-photo-7068406.jpeg?auto=compress&cs=tinysrgb&h=300&w=300',
    'https://images.pexels.com/photos/13844013/pexels-photo-13844013.jpeg?auto=compress&cs=tinysrgb&h=650&w=1600',
    'sales@nilemobile.example', '+20 100 000 0000', '2020-01-01')
ON CONFLICT (id) DO NOTHING;

INSERT INTO shops (id, owner_id, slug, name, tagline, about, country, city, category, tags, logo, cover, contact_email, contact_phone, created_at)
VALUES
  ('a0000004-0000-0000-0000-000000000004', NULL, 'atlas-home',
    '{"ar":"أطلس للمنزل","en":"Atlas Home","fr":"Atlas Maison"}',
    '{"ar":"أثاث وديكور بلمسة مغربية","en":"Furniture and decor with a Moroccan touch","fr":"Meubles et déco avec touche marocaine"}',
    '{"ar":"ورشة أثاث في مراكش تجمع بين الحرفية التقليدية والتصميم الحديث.","en":"A Marrakech furniture workshop blending traditional craft with modern design.","fr":"Atelier de meubles à Marrakech, artisanat traditionnel et design moderne."}',
    'MA', '{"ar":"مراكش","en":"Marrakech","fr":"Marrakech"}', 'home',
    '[{"ar":"أثاث","en":"Furniture","fr":"Meubles"},{"ar":"ديكور","en":"Decor","fr":"Déco"}]',
    'https://images.pexels.com/photos/7573934/pexels-photo-7573934.jpeg?auto=compress&cs=tinysrgb&h=300&w=300',
    'https://images.pexels.com/photos/1648776/pexels-photo-1648776.jpeg?auto=compress&cs=tinysrgb&h=650&w=1600',
    'contact@atlas-home.example', '+212 600 000 000', '2019-01-01')
ON CONFLICT (id) DO NOTHING;

INSERT INTO shops (id, owner_id, slug, name, tagline, about, country, city, category, tags, logo, cover, contact_email, contact_phone, created_at)
VALUES
  ('a0000005-0000-0000-0000-000000000005', NULL, 'glow-beauty',
    '{"ar":"غلو للجمال","en":"Glow Beauty","fr":"Glow Beauty"}',
    '{"ar":"عناية بالبشرة ومكياج طبيعي","en":"Skincare and natural makeup","fr":"Soins de peau et maquillage naturel"}',
    '{"ar":"علامة جمال سعودية تختار منتجات العناية بعناية لكل أنواع البشرة.","en":"A Saudi beauty brand curating skincare for every skin type.","fr":"Marque saoudienne de beauté, soins sélectionnés pour chaque type de peau."}',
    'SA', '{"ar":"الرياض","en":"Riyadh","fr":"Riyad"}', 'beauty',
    '[{"ar":"عناية","en":"Skincare","fr":"Soins"},{"ar":"مكياج","en":"Makeup","fr":"Maquillage"}]',
    'https://images.pexels.com/photos/13534508/pexels-photo-13534508.jpeg?auto=compress&cs=tinysrgb&h=300&w=300',
    'https://images.pexels.com/photos/12969358/pexels-photo-12969358.jpeg?auto=compress&cs=tinysrgb&h=650&w=1600',
    'hello@glowbeauty.example', '+966 50 000 0000', '2023-01-01')
ON CONFLICT (id) DO NOTHING;

INSERT INTO shops (id, owner_id, slug, name, tagline, about, country, city, category, tags, logo, cover, contact_email, contact_phone, created_at)
VALUES
  ('a0000006-0000-0000-0000-000000000006', NULL, 'champion-sports',
    '{"ar":"تشامبيون للرياضة","en":"Champion Sports","fr":"Champion Sports"}',
    '{"ar":"معدات وملابس رياضية لكل الأنشطة","en":"Sports gear and apparel for every activity","fr":"Équipements et vêtements de sport pour toutes les activités"}',
    '{"ar":"متجر رياضي في لندن يوفّر معدات عالية الأداء للمحترفين والهواة.","en":"A London sports store providing high-performance gear for pros and hobbyists.","fr":"Boutique de sport à Londres, matériel haute performance pour pros et amateurs."}',
    'GB', '{"ar":"لندن","en":"London","fr":"Londres"}', 'sports',
    '[{"ar":"معدات","en":"Equipment","fr":"Équipement"},{"ar":"ملابس","en":"Apparel","fr":"Vêtements"}]',
    'https://images.pexels.com/photos/4931355/pexels-photo-4931355.jpeg?auto=compress&cs=tinysrgb&h=300&w=300',
    'https://images.pexels.com/photos/6740821/pexels-photo-6740821.jpeg?auto=compress&cs=tinysrgb&h=650&w=1600',
    'team@championsports.example', '+44 20 0000 0000', '2021-01-01')
ON CONFLICT (id) DO NOTHING;

INSERT INTO shops (id, owner_id, slug, name, tagline, about, country, city, category, tags, logo, cover, contact_email, contact_phone, created_at)
VALUES
  ('a0000007-0000-0000-0000-000000000007', NULL, 'bazaar-fresh-grocery',
    '{"ar":"بازار فريش للبقالة","en":"Bazaar Fresh Grocery","fr":"Bazaar Fresh Épicerie"}',
    '{"ar":"أطعمة طازجة ومستلزمات يومية","en":"Fresh food and daily essentials","fr":"Produits frais et essentials du quotidien"}',
    '{"ar":"بقالة إسطنبولية تورد منتجات طازجة يومياً من المزارع المحلية.","en":"An Istanbul grocer sourcing fresh products daily from local farms.","fr":"Épicerie stambouliote, produits frais quotidiens de fermes locales."}',
    'TR', '{"ar":"إسطنبول","en":"Istanbul","fr":"Istanbul"}', 'groceries',
    '[{"ar":"طازج","en":"Fresh","fr":"Frais"},{"ar":"يوميات","en":"Daily","fr":"Quotidien"}]',
    'https://images.pexels.com/photos/8475169/pexels-photo-8475169.jpeg?auto=compress&cs=tinysrgb&h=300&w=300',
    'https://images.pexels.com/photos/2449665/pexels-photo-2449665.jpeg?auto=compress&cs=tinysrgb&h=650&w=1600',
    'order@bazaarfresh.example', '+90 212 000 0000', '2022-01-01')
ON CONFLICT (id) DO NOTHING;

-- =========================================================
-- Seed products (reference seeded shop UUIDs)
-- =========================================================
INSERT INTO products (shop_id, title, description, price, currency, category, country, city, image, status, created_at)
SELECT 'a0000001-0000-0000-0000-000000000001',
  '{"ar":"حقيبة يد جلدية فاخرة","en":"Premium leather handbag","fr":"Sac à main en cuir premium"}',
  '{"ar":"حقيبة يد جلد طبيعي بتصميم أنيق، مناسبة لكل المناسبات.","en":"Genuine leather handbag with an elegant design, suitable for every occasion.","fr":"Sac à main en cuir véritable au design élégant, pour toutes les occasions."}',
  180, 'EUR', 'fashion', 'FR', '{"ar":"باريس","en":"Paris","fr":"Paris"}',
  'https://images.pexels.com/photos/27046146/pexels-photo-27046146.jpeg?auto=compress&cs=tinysrgb&h=600&w=600',
  'active', '2025-09-12'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE shop_id='a0000001-0000-0000-0000-000000000001' AND title->>'en' = 'Premium leather handbag');

INSERT INTO products (shop_id, title, description, price, currency, category, country, city, image, status, created_at)
SELECT 'a0000001-0000-0000-0000-000000000001',
  '{"ar":"حقيبة جلد بنية عصرية","en":"Modern brown leather bag","fr":"Sac en cuir marron moderne"}',
  '{"ar":"حقيبة كتف جلدية بلون بني دافئ وحزام قابل للتعديل.","en":"Brown leather shoulder bag with warm tone and adjustable strap.","fr":"Sac bandoulière en cuir marron, ton chaud et lanière réglable."}',
  145, 'EUR', 'fashion', 'FR', '{"ar":"باريس","en":"Paris","fr":"Paris"}',
  'https://images.pexels.com/photos/27204287/pexels-photo-27204287.jpeg?auto=compress&cs=tinysrgb&h=600&w=600',
  'active', '2025-09-20'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE shop_id='a0000001-0000-0000-0000-000000000001' AND title->>'en' = 'Modern brown leather bag');

INSERT INTO products (shop_id, title, description, price, currency, category, country, city, image, status, created_at)
SELECT 'a0000002-0000-0000-0000-000000000002',
  '{"ar":"لوحة مفاتيح ميكانيكية","en":"Mechanical keyboard","fr":"Clavier mécanique"}',
  '{"ar":"لوحة مفاتيح ميكانيكية بإضاءة خلفية ومفاتيح قابلة للتبديل.","en":"Mechanical keyboard with backlight and hot-swappable keys.","fr":"Clavier mécanique rétroéclairé avec touches interchangeables."}',
  320, 'AED', 'electronics', 'AE', '{"ar":"دبي","en":"Dubai","fr":"Dubaï"}',
  'https://images.pexels.com/photos/38555192/pexels-photo-38555192.jpeg?auto=compress&cs=tinysrgb&h=600&w=600',
  'active', '2025-10-01'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE shop_id='a0000002-0000-0000-0000-000000000002' AND title->>'en' = 'Mechanical keyboard');

INSERT INTO products (shop_id, title, description, price, currency, category, country, city, image, status, created_at)
SELECT 'a0000002-0000-0000-0000-000000000002',
  '{"ar":"سماعة مكتبية لاسلكية","en":"Wireless desktop speaker","fr":"Enceinte de bureau sans fil"}',
  '{"ar":"سماعة لاسلكية بصوت محيطي وبطارية تدوم 12 ساعة.","en":"Wireless speaker with surround sound and 12-hour battery.","fr":"Enceinte sans fil son surround et 12h d''autonomie."}',
  210, 'AED', 'electronics', 'AE', '{"ar":"دبي","en":"Dubai","fr":"Dubaï"}',
  'https://images.pexels.com/photos/16888144/pexels-photo-16888144.jpeg?auto=compress&cs=tinysrgb&h=600&w=600',
  'active', '2025-10-05'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE shop_id='a0000002-0000-0000-0000-000000000002' AND title->>'en' = 'Wireless desktop speaker');

INSERT INTO products (shop_id, title, description, price, currency, category, country, city, image, status, created_at)
SELECT 'a0000003-0000-0000-0000-000000000003',
  '{"ar":"هاتف ذكي حديث","en":"Latest smartphone","fr":"Smartphone récent"}',
  '{"ar":"هاتف ذكي بشاشة 6.7 بوصة وكاميرا مزدوجة وضمان رسمي.","en":"Smartphone with 6.7\" display, dual camera and official warranty.","fr":"Smartphone écran 6.7\", double caméra et garantie officielle."}',
  8500, 'EGP', 'phones', 'EG', '{"ar":"القاهرة","en":"Cairo","fr":"Le Caire"}',
  'https://images.pexels.com/photos/7068406/pexels-photo-7068406.jpeg?auto=compress&cs=tinysrgb&h=600&w=600',
  'active', '2025-10-10'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE shop_id='a0000003-0000-0000-0000-000000000003' AND title->>'en' = 'Latest smartphone');

INSERT INTO products (shop_id, title, description, price, currency, category, country, city, image, status, created_at)
SELECT 'a0000003-0000-0000-0000-000000000003',
  '{"ar":"غطاء حماية شفاف","en":"Clear protective case","fr":"Coque de protection transparente"}',
  '{"ar":"غطاء شفاف مقاوم للصدمات يحافظ على مظهر الهاتف.","en":"Shock-resistant clear case that keeps the phone''s look.","fr":"Coque transparente anti-choc qui conserve l''aspect du téléphone."}',
  120, 'EGP', 'phones', 'EG', '{"ar":"القاهرة","en":"Cairo","fr":"Le Caire"}',
  'https://images.pexels.com/photos/13844013/pexels-photo-13844013.jpeg?auto=compress&cs=tinysrgb&h=600&w=600',
  'active', '2025-10-12'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE shop_id='a0000003-0000-0000-0000-000000000003' AND title->>'en' = 'Clear protective case');

INSERT INTO products (shop_id, title, description, price, currency, category, country, city, image, status, created_at)
SELECT 'a0000004-0000-0000-0000-000000000004',
  '{"ar":"أريكة رمادية أنيقة","en":"Elegant gray sofa","fr":"Canapé gris élégant"}',
  '{"ar":"أريكة رمادية بوسادة فنية تناسب الصالونات الحديثة.","en":"Gray sofa with artistic cushion, fits modern living rooms.","fr":"Canapé gris avec coussin artistique, pour salons modernes."}',
  4200, 'MAD', 'home', 'MA', '{"ar":"مراكش","en":"Marrakech","fr":"Marrakech"}',
  'https://images.pexels.com/photos/11295890/pexels-photo-11295890.jpeg?auto=compress&cs=tinysrgb&h=600&w=600',
  'active', '2025-09-28'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE shop_id='a0000004-0000-0000-0000-000000000004' AND title->>'en' = 'Elegant gray sofa');

INSERT INTO products (shop_id, title, description, price, currency, category, country, city, image, status, created_at)
SELECT 'a0000004-0000-0000-0000-000000000004',
  '{"ar":"غرفة معيشة فاخرة","en":"Luxury living room set","fr":"Ensemble salon de luxe"}',
  '{"ar":"طقم غرفة معيشة كامل بثريّة وأرائك وكراسي أنيقة.","en":"Complete living room set with chandelier, sofas and elegant chairs.","fr":"Ensemble salon complet avec lustre, canapés et chaises élégantes."}',
  12500, 'MAD', 'home', 'MA', '{"ar":"مراكش","en":"Marrakech","fr":"Marrakech"}',
  'https://images.pexels.com/photos/1648776/pexels-photo-1648776.jpeg?auto=compress&cs=tinysrgb&h=600&w=600',
  'active', '2025-10-02'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE shop_id='a0000004-0000-0000-0000-000000000004' AND title->>'en' = 'Luxury living room set');

INSERT INTO products (shop_id, title, description, price, currency, category, country, city, image, status, created_at)
SELECT 'a0000005-0000-0000-0000-000000000005',
  '{"ar":"كريم أساس BB","en":"BB cream foundation","fr":"Crème BB"}',
  '{"ar":"كريم أساس خفيف بتغطية طبيعية وحماية من الشمس.","en":"Light foundation with natural coverage and sun protection.","fr":"Fond de teint léger, couverture naturelle et protection solaire."}',
  95, 'SAR', 'beauty', 'SA', '{"ar":"الرياض","en":"Riyadh","fr":"Riyad"}',
  'https://images.pexels.com/photos/13534508/pexels-photo-13534508.jpeg?auto=compress&cs=tinysrgb&h=600&w=600',
  'active', '2025-10-08'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE shop_id='a0000005-0000-0000-0000-000000000005' AND title->>'en' = 'BB cream foundation');

INSERT INTO products (shop_id, title, description, price, currency, category, country, city, image, status, created_at)
SELECT 'a0000005-0000-0000-0000-000000000005',
  '{"ar":"طقم العناية بالبشرة","en":"Skincare set","fr":"Coffret soins de peau"}',
  '{"ar":"طقم متكامل من السيروم والمرطب والغسول للبشرة المشتعلة.","en":"Complete set of serum, moisturizer and cleanser for glowing skin.","fr":"Ensemble sérum, hydratant et nettoyant pour peau éclatante."}',
  220, 'SAR', 'beauty', 'SA', '{"ar":"الرياض","en":"Riyadh","fr":"Riyad"}',
  'https://images.pexels.com/photos/20382236/pexels-photo-20382236.jpeg?auto=compress&cs=tinysrgb&h=600&w=600',
  'active', '2025-10-11'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE shop_id='a0000005-0000-0000-0000-000000000005' AND title->>'en' = 'Skincare set');

INSERT INTO products (shop_id, title, description, price, currency, category, country, city, image, status, created_at)
SELECT 'a0000006-0000-0000-0000-000000000006',
  '{"ar":"حذاء رياضي أبيض","en":"White sneakers","fr":"Baskets blanches"}',
  '{"ar":"حذاء رياضي أبيض بتصميم بسيط ومريح للاستخدام اليومي.","en":"Minimal, comfortable white sneakers for everyday wear.","fr":"Baskets blanches minimalistes et confortables au quotidien."}',
  75, 'GBP', 'sports', 'GB', '{"ar":"لندن","en":"London","fr":"Londres"}',
  'https://images.pexels.com/photos/27204251/pexels-photo-27204251.jpeg?auto=compress&cs=tinysrgb&h=600&w=600',
  'active', '2025-09-25'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE shop_id='a0000006-0000-0000-0000-000000000006' AND title->>'en' = 'White sneakers');

INSERT INTO products (shop_id, title, description, price, currency, category, country, city, image, status, created_at)
SELECT 'a0000006-0000-0000-0000-000000000006',
  '{"ar":"طقم أثقال منزلية","en":"Home workout dumbbell set","fr":"Set d''haltères maison"}',
  '{"ar":"طابق أثقال وأشرطة مقاومة وحذاء رياضي لتمرين منزلي كامل.","en":"Dumbbells, resistance bands and sneakers for a full home workout.","fr":"Haltères, élastiques et baskets pour séance maison complète."}',
  130, 'GBP', 'sports', 'GB', '{"ar":"لندن","en":"London","fr":"Londres"}',
  'https://images.pexels.com/photos/6740821/pexels-photo-6740821.jpeg?auto=compress&cs=tinysrgb&h=600&w=600',
  'active', '2025-10-03'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE shop_id='a0000006-0000-0000-0000-000000000006' AND title->>'en' = 'Home workout dumbbell set');

INSERT INTO products (shop_id, title, description, price, currency, category, country, city, image, status, created_at)
SELECT 'a0000007-0000-0000-0000-000000000007',
  '{"ar":"خضار طازجة متنوعة","en":"Fresh mixed vegetables","fr":"Légumes frais variés"}',
  '{"ar":"تشكيلة خضار طازجة من المزارع المحلية تورد صباحاً.","en":"Fresh mixed vegetables from local farms, delivered mornings.","fr":"Assortiment de légumes frais de fermes locales, livrés le matin."}',
  180, 'TND', 'groceries', 'TR', '{"ar":"إسطنبول","en":"Istanbul","fr":"Istanbul"}',
  'https://images.pexels.com/photos/9705821/pexels-photo-9705821.jpeg?auto=compress&cs=tinysrgb&h=600&w=600',
  'active', '2025-10-14'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE shop_id='a0000007-0000-0000-0000-000000000007' AND title->>'en' = 'Fresh mixed vegetables');

INSERT INTO products (shop_id, title, description, price, currency, category, country, city, image, status, created_at)
SELECT 'a0000007-0000-0000-0000-000000000007',
  '{"ar":"سلة فواكه موسمية","en":"Seasonal fruit basket","fr":"Panier de fruits de saison"}',
  '{"ar":"سلة فواكه موسمية طازجة تكفي لعائلة لمدة أسبوع.","en":"Fresh seasonal fruit basket, enough for a family for a week.","fr":"Panier de fruits de saison frais, pour une famille une semaine."}',
  240, 'TND', 'groceries', 'TR', '{"ar":"إسطنبول","en":"Istanbul","fr":"Istanbul"}',
  'https://images.pexels.com/photos/2449665/pexels-photo-2449665.jpeg?auto=compress&cs=tinysrgb&h=600&w=600',
  'draft', '2025-10-15'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE shop_id='a0000007-0000-0000-0000-000000000007' AND title->>'en' = 'Seasonal fruit basket');
